-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.24-log - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL version:             7.0.0.4053
-- Date/time:                    2013-09-03 18:12:30
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;

-- Dumping database structure for college
DROP DATABASE IF EXISTS `university`;
CREATE DATABASE IF NOT EXISTS `college` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `college`;


-- Dumping structure for table college.courses
DROP TABLE IF EXISTS `courses`;
CREATE TABLE IF NOT EXISTS `courses` (
  `course_id` smallint(6) DEFAULT NULL,
  `course_name` varchar(255) DEFAULT NULL,
  `credits` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table college.courses: ~5 rows (approximately)
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` (`course_id`, `course_name`, `credits`) VALUES
	(10, 'African Paintings As A Feminist Genre', 1),
	(20, 'Life Of Russian Self-Actualization: A Process Approach', 3),
	(30, 'Race, Conflict, And Conflict In Polytheistic Music: Discovery, Development, and Interpretation', 4),
	(40, 'The Populist Dimension Of Southern Middle Eastern Literature', 2),
	(50, 'Masterpieces Of Middle Class Chinese Literature', 1);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;


-- Dumping structure for table college.instructors
DROP TABLE IF EXISTS `instructors`;
CREATE TABLE IF NOT EXISTS `instructors` (
  `instructor_id` smallint(6) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `dob` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table college.instructors: ~4 rows (approximately)
/*!40000 ALTER TABLE `instructors` DISABLE KEYS */;
INSERT INTO `instructors` (`instructor_id`, `firstname`, `lastname`, `dob`) VALUES
	(10, 'DARIUS', 'Bokman', '1957-07-08 00:00:00'),
	(20, 'CAREY', 'Mccament', '1984-01-03 00:00:00'),
	(30, 'FIDEL', 'Blondell', '1976-04-05 00:00:00'),
	(40, 'ELWOOD', 'Farb', '1986-09-01 00:00:00');
/*!40000 ALTER TABLE `instructors` ENABLE KEYS */;


-- Dumping structure for table college.registrations
DROP TABLE IF EXISTS `registrations`;
CREATE TABLE IF NOT EXISTS `registrations` (
  `course_id` smallint(6) DEFAULT NULL,
  `section_name` varchar(255) DEFAULT NULL,
  `student_id` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table college.registrations: ~17 rows (approximately)
/*!40000 ALTER TABLE `registrations` DISABLE KEYS */;
INSERT INTO `registrations` (`course_id`, `section_name`, `student_id`) VALUES
	(10, 'AA', 1),
	(10, 'AA', 4),
	(10, 'AA', 11),
	(10, 'AA', 14),
	(10, 'AA', 15),
	(10, 'AA', 18),
	(10, 'AB', 5),
	(10, 'AB', 10),
	(10, 'AB', 17),
	(30, 'WB', 13),
	(30, 'WB', 14),
	(30, 'WB', 16),
	(30, 'WB', 17),
	(30, 'WB', 19),
	(30, 'WB', 21),
	(30, 'WB', 22),
	(30, 'WB', 24);
/*!40000 ALTER TABLE `registrations` ENABLE KEYS */;


-- Dumping structure for table college.sections
DROP TABLE IF EXISTS `sections`;
CREATE TABLE IF NOT EXISTS `sections` (
  `course_id` smallint(6) DEFAULT NULL,
  `section_name` varchar(255) DEFAULT NULL,
  `instructor_id` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table college.sections: ~6 rows (approximately)
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` (`course_id`, `section_name`, `instructor_id`) VALUES
	(10, 'AA', 10),
	(10, 'AB', 10),
	(30, 'AA', 20),
	(30, 'AB', 20),
	(30, 'WB', 40),
	(40, 'AA', 10);
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;


-- Dumping structure for table college.students
DROP TABLE IF EXISTS `students`;
CREATE TABLE IF NOT EXISTS `students` (
  `student_id` smallint(6) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `height` double DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `dob` datetime DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table college.students: ~25 rows (approximately)
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` (`student_id`, `firstname`, `lastname`, `height`, `weight`, `dob`, `state`) VALUES
	(1, 'DARIUS', 'Brands', 76.2, 197.5, '1985-02-27 00:00:00', 'MN'),
	(2, 'BRAIN', 'Kunsch', 74.3, 185.4, '1986-10-05 00:00:00', 'MD'),
	(3, 'KENDRICK', 'Kafton', 72.9, 181, '1989-11-23 00:00:00', 'VT'),
	(4, 'ARMAND', 'Lachat', 72.2, 189.7, '1986-09-14 00:00:00', 'MT'),
	(5, 'ALI', 'Borio', 74.3, 180.6, '1987-04-17 00:00:00', 'FL'),
	(6, 'JACKSON', 'Samay', 68.5, 175, '1986-01-10 00:00:00', 'MN'),
	(7, 'DANE', 'Talahytewa', 69.9, 199.4, '1992-02-26 00:00:00', 'CT'),
	(8, 'CLIFF', 'Casher', 73.9, 201.7, '1990-05-22 00:00:00', 'ID'),
	(9, 'MARCEL', 'Jacot', 76.5, 183.5, '1983-08-30 00:00:00', 'ND'),
	(10, 'MARCEL', 'Titze', 70, 188.2, '1992-12-24 00:00:00', 'HI'),
	(11, 'RAPHAEL', 'Sitko', 72.9, 196.4, '1989-04-10 00:00:00', 'ND'),
	(12, 'ALI', 'Aufderheide', 71.9, 193.2, '1988-08-19 00:00:00', 'AL'),
	(13, 'CAREY', 'Dense', 73.7, 180.8, '1990-12-11 00:00:00', 'FL'),
	(14, 'JACKSON', 'Vay', 73.7, 186.3, '1987-11-09 00:00:00', 'NJ'),
	(15, 'BRAIN', 'Gattshall', 69.5, 187, '1989-06-18 00:00:00', 'ND'),
	(16, 'KENDRICK', 'Burde', 73.2, 202.9, '1987-06-07 00:00:00', 'FL'),
	(17, 'ALI', 'Dicapua', 70.8, 183.1, '1987-09-15 00:00:00', 'ME'),
	(18, 'JACKSON', 'Aitcheson', 71.3, 203.9, '1990-11-21 00:00:00', 'NH'),
	(19, 'MOISES', 'Nore', 72.1, 175.3, '1986-03-11 00:00:00', 'ME'),
	(20, 'CLIFF', 'Shely', 72.4, 196.3, '1991-04-24 00:00:00', 'OK'),
	(21, 'ALVARO', 'Billiott', 73.1, 208.5, '1984-08-14 00:00:00', 'DE'),
	(22, 'JEFFRY', 'Pacitto', 72.6, 184.9, '1988-08-20 00:00:00', 'NH'),
	(23, 'BRYON', 'Younie', 75.8, 191.4, '1986-10-15 00:00:00', 'ME'),
	(24, 'JACKSON', 'Sherick', 70.9, 186.9, '1983-06-09 00:00:00', 'FL'),
	(25, 'MOISES', 'Kopperman', 75.6, 191.8, '1990-02-08 00:00:00', 'HI');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
/*!40014 SET FOREIGN_KEY_CHECKS=1 */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
